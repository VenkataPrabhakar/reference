//
//  ViewController.swift
//  Dandyala_Exam01Part02
//
//  Created by Dandyala,Harshita on 2/22/22.
//

import UIKit



class ViewController: UIViewController {
    
    var library=["book1", "book2", "book3", "book4","book5","book6","book7","book8","book9","book10"]
    var Student=["John","Paul","Alexa", "David"]
    
    var record = [ "John": [],
                   "Paul" : ["book1","book2"],
                   "Alexa" : ["book1", "book2", "book3","book4"]
                   
    
    ]

    @IBOutlet weak var StudentName: UILabel!
    
    
    @IBOutlet weak var BookName: UILabel!
    
    
    @IBOutlet weak var StudentNameInputTF: UITextField!
    
    
    @IBOutlet weak var BookNameInputTF: UITextField!
                
                
    
    @IBOutlet weak var DisplayLabel: UILabel!
                
                
    override func viewDidLoad() {
        super.viewDidLoad()
      //  self.StudentNameInputTF
        //self.DisplayLabel.text
        self.StudentNameInputTF.isEnabled = true
        self.BookNameInputTF.isEnabled = false
        self.CheckStudent.isEnabled = true
        self.BookName.isEnabled = false
        self.StudentName.isEnabled = true
        self.CheckBook.isEnabled = false
        self.CheckOut.isEnabled = false
        

        // Do any additional setup after loading the view.
        
    }
    
    
    @IBAction func CheckStudent(_ sender: UIButton) {
        
        if(Student.contains(StudentNameInputTF.text!))
        {
            self.BookNameInputTF.isEnabled = true
            self.BookName.isEnabled = true
            self.CheckBook.isEnabled = true
            
        }
        else{
            
            //  let d = DisplayLabel.text!
            self.DisplayLabel.text = "Stuendt records not found"
           
            
        }
        
    }
    
    @IBAction func CheckBook(_ sender: UIButton) {
       
      
        if(library.contains(BookNameInputTF.text!))
        {
            
            var check=true
            var data = record[StudentNameInputTF.text!]
            
            if(data?.count ?? 0  < 4){
            let cnt:Int = data?.count ?? 0
            
            var x:Int=0
            while(x < cnt){
                var d1 = data?[x]
                var d2 = BookNameInputTF.text!
                if(d1 == d2){
                    self.DisplayLabel.text = "Book is already assigned to you"
                    self.CheckOut.isEnabled = false
                    check=false
                }
                x=x+1
                
            }
            if(check){
                self.DisplayLabel.text = "\(BookNameInputTF.text!) is ready for checkout "
                self.CheckOut.isEnabled = true
            }
                
            }
            else{
                self.DisplayLabel.text = "You  cannot  check  out  more  than  four  books"
                self.CheckOut.isEnabled = false
            }
            
        }
        
        else
        {
            self.DisplayLabel.text = "\(BookNameInputTF.text!) is not available"
            self.CheckOut.isEnabled = false
                      
        }
    }
    @IBOutlet weak var CheckStudent: UIButton!
        

   
    @IBOutlet weak var CheckBook: UIButton!
    
    @IBOutlet weak var CheckOut: UIButton!
    
  
    
    @IBAction func CheckOut(_ sender: UIButton) {
        var data = record[StudentNameInputTF.text!]
        data?.append(BookNameInputTF.text!)
        record[StudentNameInputTF.text!] = data
        var name = "Name :"+StudentNameInputTF.text!
        self.DisplayLabel.text = "\(name)\("\r\n books checked out")\( record[StudentNameInputTF.text!]!.description)"
        self.CheckOut.isEnabled = false
        
        


    }
    
}

